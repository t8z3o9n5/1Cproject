package com.orthocanna.a1c

data class MainDataClassRecyclerView(var dataImage: Int, var dataTitle: String)
