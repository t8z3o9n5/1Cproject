package com.orthocanna.a1c

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class InventoryListLastActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inventory_list_last)
    }
}